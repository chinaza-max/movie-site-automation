const express=require("express")
const router=express.Router();
const puppeteer = require('puppeteer');
var bestcaptchasolver = require('bestcaptchasolver');
bestcaptchasolver.set_access_token('CBAB90AE88474E509F64ADE5123D12E0');


router.post('/api',async(req, res,)=>{

    console.log(req.body.data)
      console.log("LAUNCHING2")
      const browser = await puppeteer.launch();
      const page = await browser.newPage();
      await page.setDefaultNavigationTimeout(0);
      console.log("ACCESSING SITE2")
      await page.goto(req.body.data);
      console.log("started2")
      const movies = await page.evaluate(() => Array.from(document.querySelectorAll('.data a'), element => {    return(
        {name: element.innerText,link:element.getAttribute('href')}
      )}));
      console.log("movies")
      await browser.close();
      res.json({"express":movies})
           
})
router.post('/downloadAPI',async(req, res,)=>{

  let url=req.body.data
  console.log()
  for(let i=0;i<url.length;i++){
    const browser = await puppeteer.launch({headless: false,});
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(0);
    await page.goto(url[i]);
    console.log("started2")
    //await page.evaluate(() => Array.from(document.querySelectorAll('.data a'), element =>element[1].click()));
    await page.evaluate(() => document.querySelectorAll('.data a')[1].click());
    await browser.close();
  }
 
 
 
         
})

module.exports=router;


//https://jsoverson.medium.com/bypassing-captchas-with-headless-chrome-93f294518337